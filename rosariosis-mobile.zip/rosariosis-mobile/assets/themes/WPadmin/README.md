## Grunt

The `stylesheet.css` file is generated using [Grunt](https://gruntjs.com/getting-started) (see `package.json` & `Gruntfile.js` files at the root of this project).


## Copyright

The CSS files and images of the WPadmin theme were copied and adapted from **WordPress** 2.5, a free software released under the terms of the GPL version 2.

Copyright 2011 by the contributors
