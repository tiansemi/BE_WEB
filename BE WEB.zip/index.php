<?php
$host = 'localhost';
$db   = 'be_web';
$user = 'tiansemi';
$pass = '*ù$ù*ù$ù';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$opt = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $opt);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = hash('sha512', $_POST["password"]); // Hash the password

    // Chercher dans la table 'ETUDIANT'
    $stmt = $pdo->prepare("SELECT * FROM ETUDIANT WHERE Matricule = :username AND password = :password");
    $stmt->execute(['username' => $username, 'password' => $password]); 
    $user = $stmt->fetch();

    if (!$user) {
        // Si l'utilisateur n'est pas trouvé dans 'ETUDIANT', chercher dans 'ENSEIGNANT'
        $stmt = $pdo->prepare("SELECT * FROM ENSEIGNANT WHERE Code_ens = :username AND password = :password");
        $stmt->execute(['username' => $username, 'password' => $password]); 
        $user = $stmt->fetch();
    }

    if ($user) {
        echo "Bienvenue, " . $user['Nom'];
        // Redirigez l'utilisateur vers la page d'accueil ou la page de tableau de bord ici
    } else {
        echo "Identifiant ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Example</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
    <script type="text/javascript" src="bootstrap.bundle.min.js"></script>
</head>

<body>

	<section class="text-center" style="">
		<!-- Background image -->
        <div class="p-5 bg-image" style="
	        background-image: url('171.jpg');
	        height: 300px;
	        background-position: center;
	        background-size: cover;
	        "></div>
        <div class="d-flex flex-row">
            <div class="col-3"></div>
            <div class="card mx-4 mx-md-5 shadow-5-strong bg-body-tertiary col-6 offset-3" style="margin-top: -100px;
		        backdrop-filter: blur(30px);
		        margin-left: 0 !important;
		        margin-right: 0 !important;">
                <div class="card-body py-5 px-md-5" style="">
                    <div class="row d-flex justify-content-center">
                        <div class="col-lg-8">
                            <h2 class="fw-bold mb-5">Connexion</h2>
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                                <!-- Email input -->
                                <div data-mdb-input-init="" class="form-outline mb-4">
                                    <input placeholder="Matricule" type="text" id="username" class="form-control text-center" name="username" required>
                                </div>
                                <!-- Password input -->
                                <div data-mdb-input-init="" class="form-outline mb-4">
                                    <input placeholder="Mot de passe" type="password" id="form3Example4" class="form-control text-center" id="password" name="password" required>
                                </div>
                                <!-- Submit button -->
                                <button type="submit" data-mdb-button-init="" data-mdb-ripple-init="" class="btn btn-primary btn-block mb-4">Se connecter</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>
</html>
